/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.MetodosBiblioteca;

/**
 *
 * @author Pablo Herrero
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MetodosBiblioteca metodos = new MetodosBiblioteca();
        try {
            // APARTADO 1
            // Retorna todos los libros
            ResultSet libros = metodos.retornarLibros(true);
            
            // Devolver un ResultSet con los datos de los libros y visualizarlos en otro método
//            metodos.mostrarResultSet(libros);
            
            // APARTADO 2
            // Insertar un libro
//            metodos.insertarLibro("000000005", "AD para todos", "JL", 900, "2020-10-10", true, "2021-03-10");
//            metodos.insertarLibro("000000006", "PSP para todos", "JL", 900, "2020-10-10", true, "2021-03-10");

            // APARTADO 3
            // Eliminar un libro por id o por título.
//            metodos.eliminarLibro("000000005", true);
//            metodos.eliminarLibro("PSP para todos", false);

            // APARTADO 4
            // Seleccionar todos los libros de un autor usando un PreparedStatement
//            ResultSet librosPorAutor = metodos.retornarLibrosPorAutor("Robert Martin");
//            metodos.mostrarResultSet(librosPorAutor);
            
            // APARTADO 5
            // Retorna todos los nombres de los socios seguidos los títulos prestados.  (Devolver un ResultSet y visualizarlo en otro método),  también los puede devolver ordenados por titulo si el usuario lo desea.
//            ResultSet sociosYTitulosPrestados = metodos.retornarNombresSociosYTitulosPrestados("1", true);
//            metodos.mostrarResultSet(sociosYTitulosPrestados);

            // APARTADO 6
            // Retorna todos los nombres de los socios que tienen un determinado libro prestado, por título o ISBN (usar PreparedStatement). 
            ResultSet nombresSociosPorLibro = metodos.retornarNombresSociosPorLibroPrestado("000000004", true);
            metodos.mostrarResultSet(nombresSociosPorLibro);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
