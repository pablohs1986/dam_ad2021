/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ad_proyectoclientes;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import jaxb.clientes.Clientes;
import jaxb.clientes.ObjectFactory;
import modelo.ExcepcionesClientes;
import modelo.MetodosClientes;

/**
 *
 * @author Pablo
 */
public class AD_ProyectoCLientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        File archivo = new File("clientes.xml");
        MetodosClientes metodos = new MetodosClientes();
        
       
        try {
            JAXBElement elemento = metodos.unmarshalizar(archivo);
            
            ObjectFactory factoria = new ObjectFactory();
            
            Clientes nodoClientes = factoria.createClientes();
            
            nodoClientes = (Clientes) elemento.getValue();
            
            metodos.unmarshalizar(archivo);
            
            System.out.println(metodos.totalClientes(nodoClientes));
        } catch (JAXBException ex) {
            Logger.getLogger(AD_ProyectoCLientes.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ExcepcionesClientes ex) {
            System.out.println("No se ha encontrado ningún cliente");
        }
        
    }
    
}
