/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.File;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;
import jaxb.clientes.Clientes;
import jaxb.clientes.Clientes.Cliente;

/**
 *
 * @author Pablo
 */
public class MetodosClientes implements InterfaceClientes{

    @Override
    public JAXBElement unmarshalizar(File archivoXML) throws JAXBException{
        
        JAXBContext contexto = JAXBContext.newInstance("jaxb.clientes");
        Unmarshaller unmarshaller = contexto.createUnmarshaller();
        JAXBElement elemento = unmarshaller.unmarshal(new StreamSource("clientes.xml"), Clientes.class);
        return elemento;
    }

    @Override
    public int totalClientes(Clientes nodoClientes) throws ExcepcionesClientes {
        
        
        List<Cliente> listaCliente = nodoClientes.getCliente();
        return listaCliente.size();
    }
    
}
