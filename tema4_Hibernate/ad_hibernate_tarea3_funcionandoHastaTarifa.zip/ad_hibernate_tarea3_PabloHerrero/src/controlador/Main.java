/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.Date;
import modelo.dao.AbstractDAO;
import modelo.dto.Linea;
import modelo.dto.Llamada;
import modelo.dto.Terminal;

/**
 *
 * @author Pablo Herrero
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Creo llamadas
        Llamada llamada1 = new Llamada();
        llamada1.setTelefonoOrigen("111111111");
        llamada1.setTelefonoDestino("222222222");
        llamada1.setMinutosConsumidos(10);
        llamada1.setFechaInicio(new Date());
        
        // Creo terminal
        Terminal terminal1 = new Terminal();
        terminal1.setImei("1111");
        terminal1.setMarca("MarcaA");
        terminal1.setModelo("ModeloA");
        
        // Creo líneas
        Linea linea1 = new Linea();
        linea1.setNumeroTelefono("111111111");
        linea1.setDatosDisponibles(10000);
        linea1.setMinutosConsumidos(1000);

        // Asigno llamadas a líneas
        linea1.addLlamada(llamada1);
        
        // Asigno terminales a líneas
        linea1.setTerminal(terminal1);
        
        // Persisto
        AbstractDAO.almacenarEntidad(linea1);
        
    }
    
}
