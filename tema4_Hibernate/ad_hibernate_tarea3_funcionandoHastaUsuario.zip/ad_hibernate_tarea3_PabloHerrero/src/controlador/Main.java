/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.Date;
import modelo.dao.AbstractDAO;
import modelo.dto.Linea;
import modelo.dto.Llamada;
import modelo.dto.Tarifa;
import modelo.dto.Terminal;
import modelo.dto.Usuario;

/**
 *
 * @author Pablo Herrero
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Creo llamadas
        Llamada llamada1 = new Llamada();
        llamada1.setTelefonoOrigen("111111111");
        llamada1.setTelefonoDestino("222222222");
        llamada1.setMinutosConsumidos(10);
        llamada1.setFechaInicio(new Date());
        
        // Creo terminales
        Terminal terminal1 = new Terminal();
        terminal1.setImei("1111");
        terminal1.setMarca("MarcaA");
        terminal1.setModelo("ModeloA");
        
        // Crep tarifas
        Tarifa tarifa1 = new Tarifa();
        tarifa1.setNombre("Tarifa1");
        tarifa1.setMinutosMaxLlamadas(100);
        tarifa1.setGigasMaxDatos(1000);
        
        // Creo líneas
        Linea linea1 = new Linea();
        linea1.setNumeroTelefono("111111111");
        linea1.setDatosDisponibles(10000);
        linea1.setMinutosConsumidos(1000);

        // Asigno llamadas a líneas
        linea1.addLlamada(llamada1);
        
        // Asigno terminales a líneas
        linea1.setTerminal(terminal1);
        
        // Asigno tarifas a líneas
        linea1.addTarifa(tarifa1);
        
        // Creo usuarios
        Usuario usuario1 = new Usuario();
        usuario1.setDni("11111111A");
        usuario1.setNombre("NombreA");
        usuario1.setApellido("ApellidoA");

        // Asigno lineas a usuarios
        usuario1.addLinea(linea1);
        
        // Persisto
        AbstractDAO.almacenarEntidad(usuario1);
        
    }
    
}
